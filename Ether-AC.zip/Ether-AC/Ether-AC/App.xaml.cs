﻿using System.Windows;

namespace Ether_AC_Launcher
{
    public partial class App : Application
    {
        protected override void OnExit(ExitEventArgs e)
        {
          
            var processes = System.Diagnostics.Process.GetProcessesByName("FortniteClient-Win64-Shipping");
            foreach (var p in processes)
                try { p.Kill(); } catch { }
            base.OnExit(e);
        }
    }
}