﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;

namespace Ether_AC
{
    public partial class MainWindow : Window
    {
        private Process? _fnProcess;
        private Process? _eacProcess;
        private Process? _lcProcess;
        private bool _isLaunched;
        private string? _fortnitePath;
        private static readonly HttpClient _httpClient = new();

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
            _fortnitePath = GetFortnitePath();
        }

        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(_fortnitePath) || !Directory.Exists(_fortnitePath))
                {
                    StatusText.Text = "Select Fortnite folder...";
                    var dialog = new Microsoft.Win32.OpenFolderDialog
                    {
                        Title = "Select Fortnite installation folder",
                        InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86)
                    };
                    if (dialog.ShowDialog() != true)
                    {
                        MessageBox.Show("Fortnite folder not selected. Exiting.", "Error");
                        Close();
                        return;
                    }
                    _fortnitePath = dialog.FolderName;
                }

                await Step("Scanning game files...", 40);
                var scanner = new PakIntegrityScanner(Path.Combine(_fortnitePath, "FortniteGame", "Content", "Paks"));
                var report = scanner.Scan();

                if (!report.IsClean)
                {
                    var sb = new System.Text.StringBuilder();
                    if (report.UnauthorizedFiles.Count > 0)
                    {
                        sb.AppendLine("Unauthorized files:");
                        foreach (var f in report.UnauthorizedFiles)
                            sb.AppendLine($" - {f}");
                    }
                    if (report.MissingFiles.Count > 0)
                    {
                        sb.AppendLine("\nMissing files:");
                        foreach (var f in report.MissingFiles)
                            sb.AppendLine($" - {f}");
                    }
                    MessageBox.Show(sb.ToString(), "Integrity Check Failed");
                    Close();
                    return;
                }

                await Step("Integrity OK...", 60);

                StatusText.Text = "Downloading Resources...";
                string dllUrl = "https://github.com/etc2251/hi/raw/refs/heads/main/Starfall.dll";
                string tempDllPath = Path.Combine(Path.GetTempPath(), "starfall.dll");
                var response = await _httpClient.GetAsync(dllUrl);
                response.EnsureSuccessStatusCode();
                var bytes = await response.Content.ReadAsByteArrayAsync();
                await File.WriteAllBytesAsync(tempDllPath, bytes);

                await Step("Injecting DLL...", 80);
                string aftermathPath = Path.Combine(_fortnitePath, "Engine", "Binaries", "ThirdParty", "NVIDIA", "NVaftermath", "Win64");
                if (!Directory.Exists(aftermathPath))
                    Directory.CreateDirectory(aftermathPath);

                File.Copy(tempDllPath, Path.Combine(aftermathPath, "GFSDK_Aftermath_Lib.x64.dll"), true);
                File.Copy(tempDllPath, Path.Combine(aftermathPath, "GFSDK_Aftermath_Lib.dll"), true);

                await Step("Launching...", 90);
                LaunchGame();

                await Step("Running", 100);

                _isLaunched = true;
                this.Visibility = Visibility.Hidden;
                this.ShowInTaskbar = false;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Anti-Cheat Error");
                Close();
            }
        }

        private string? GetFortnitePath()
        {
            string[] commonPaths = {
                @"C:\Program Files\Epic Games\Fortnite",
                @"C:\Program Files (x86)\Epic Games\Fortnite"
            };
            return commonPaths.FirstOrDefault(Directory.Exists);
        }

        private async Task Step(string text, int target)
        {
            StatusText.Text = text;
            while (LoadingBar.Value < target)
            {
                LoadingBar.Value++;
                ProgressText.Text = $"{LoadingBar.Value}%";
                await Task.Delay(15);
            }
        }

        private void LaunchGame()
        {
            if (string.IsNullOrEmpty(_fortnitePath))
                throw new InvalidOperationException("Fortnite path not set.");

            string exePath = Path.Combine(_fortnitePath, "FortniteGame", "Binaries", "Win64", "FortniteClient-Win64-Shipping.exe");
            if (!File.Exists(exePath))
                throw new FileNotFoundException("Fortnite executable not found.");

            Process.GetProcessesByName("FortniteClient-Win64-Shipping").ToList().ForEach(p => p.Kill());

            string args = "-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -nobe -fromfl=eac -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck -caldera=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50X2lkIjoiMTM5ZDAzOGFmOTM2NDcyODgxMTdlYWU3MWYxZGQ5ZTQiLCJnZW5lcmF0ZWQiOjE3MDQ0MTE5MDQsImNhbGRlcmFHdWlkIjoiODhjZmQ5NzYtM2U2OS00MWYzLWI2ODEtYzQyOTcxM2ZkMWFlIiwiYWNQcm92aWRlciI6IkVhc3lBbnRpQ2hlYXQiLCJub3RlcyI6IiIsImZhbGxiYWNrIjpmYWxzZX0.Q8hdxvrW2sH-3on6JEBLANB0rkPAGUwbZYPrCOMTtvA -AUTH_LOGIN=your_email -AUTH_PASSWORD=your_password -AUTH_TYPE=epic -backend=YourBackend";

            _fnProcess = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = exePath,
                    Arguments = args,
                    UseShellExecute = false,
                    CreateNoWindow = true
                }
            };
            _fnProcess.Start();

            string eacExe = Path.Combine(_fortnitePath, "FortniteGame", "Binaries", "Win64", "FortniteClient-Win64-Shipping_EAC.exe");
            string launcherExe = Path.Combine(_fortnitePath, "FortniteGame", "Binaries", "Win64", "FortniteLauncher.exe");
            if (File.Exists(eacExe))
            {
                _eacProcess = new Process { StartInfo = new ProcessStartInfo(eacExe, args) { UseShellExecute = false, CreateNoWindow = true } };
                _eacProcess.Start();
            }
            if (File.Exists(launcherExe))
            {
                _lcProcess = new Process { StartInfo = new ProcessStartInfo(launcherExe, args) { UseShellExecute = false, CreateNoWindow = true } };
                _lcProcess.Start();
            }

            _fnProcess.WaitForInputIdle();
        }

        private void KillFortnite()
        {
            try { _fnProcess?.Kill(); } catch { }
            try { _eacProcess?.Kill(); } catch { }
            try { _lcProcess?.Kill(); } catch { }
            Process.GetProcessesByName("FortniteClient-Win64-Shipping").ToList().ForEach(p => p.Kill());
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isLaunched)
            {
                KillFortnite();
                Application.Current.Shutdown();
            }
            else
            {
                Close();
            }
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            if (_isLaunched)
            {
                e.Cancel = true;
                this.Visibility = Visibility.Hidden;
                this.ShowInTaskbar = false;
                return;
            }
            base.OnClosing(e);
        }
    }
}