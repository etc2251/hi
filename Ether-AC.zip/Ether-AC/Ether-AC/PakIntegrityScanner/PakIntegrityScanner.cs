﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Ether_AC
{
    public class PakIntegrityScanner
    {
        private readonly string _pakDirectory;
        
        private static readonly HashSet<string> VerifiedPakFiles = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "pakchunk0-WindowsClient.pak",
            "pakchunk0-WindowsClient.sig",
            "pakchunk1-WindowsClient.pak",
            "pakchunk1-WindowsClient.sig",
            "pakchunk10-WindowsClient.pak",
            "pakchunk10-WindowsClient.sig",
            "pakchunk1000-WindowsClient.pak",
            "pakchunk1000-WindowsClient.sig",
            "pakchunk1001-WindowsClient.pak",
            "pakchunk1001-WindowsClient.sig",
            "pakchunk1002-WindowsClient.pak",
            "pakchunk1002-WindowsClient.sig",
            "pakchunk1003-WindowsClient.pak",
            "pakchunk1003-WindowsClient.sig",
            "pakchunk1004-WindowsClient.pak",
            "pakchunk1004-WindowsClient.sig",
            "pakchunk1005-WindowsClient.pak",
            "pakchunk1005-WindowsClient.sig",
            "pakchunk1006-WindowsClient.pak",
            "pakchunk1006-WindowsClient.sig",
            "pakchunk1007-WindowsClient.pak",
            "pakchunk1007-WindowsClient.sig",
            "pakchunk1008-WindowsClient.pak",
            "pakchunk1008-WindowsClient.sig",
            "pakchunk1009-WindowsClient.pak",
            "pakchunk1009-WindowsClient.sig",
            "pakchunk10_s1-WindowsClient.pak",
            "pakchunk10_s1-WindowsClient.sig",
            "pakchunk10_s2-WindowsClient.pak",
            "pakchunk10_s2-WindowsClient.sig",
            "pakchunk10_s3-WindowsClient.pak",
            "pakchunk10_s3-WindowsClient.sig",
            "pakchunk10_s4-WindowsClient.pak",
            "pakchunk10_s4-WindowsClient.sig",
            "pakchunk10_s5-WindowsClient.pak",
            "pakchunk10_s5-WindowsClient.sig",
            "pakchunk10_s6-WindowsClient.pak",
            "pakchunk10_s6-WindowsClient.sig",
            "pakchunk10_s7-WindowsClient.pak",
            "pakchunk10_s7-WindowsClient.sig",
            "pakchunk10_s8-WindowsClient.pak",
            "pakchunk10_s8-WindowsClient.sig",
            "pakchunk11-WindowsClient.pak",
            "pakchunk11-WindowsClient.sig",
            "pakchunk11_s1-WindowsClient.pak",
            "pakchunk11_s1-WindowsClient.sig",
            "pakchunk2-WindowsClient.pak",
            "pakchunk2-WindowsClient.sig",
            "pakchunk5-WindowsClient.pak",
            "pakchunk5-WindowsClient.sig",
            "pakchunk7-WindowsClient.pak",
            "pakchunk7-WindowsClient.sig",
            "pakchunk8-WindowsClient.pak",
            "pakchunk8-WindowsClient.sig",
            "pakchunk9-WindowsClient.pak",
            "pakchunk9-WindowsClient.sig",
            "pakchunk9000-WindowsClient.pak",
            "pakchunk9000-WindowsClient.sig",
        };

        public class ScanReport
        {
            public bool IsClean { get; set; }
            public List<string> UnauthorizedFiles { get; set; } = new List<string>();
            public List<string> MissingFiles { get; set; } = new List<string>();
            public string Message { get; set; }
        }

        public PakIntegrityScanner(string pakDirectory)
        {
            _pakDirectory = pakDirectory;
        }

        public ScanReport Scan()
        {
            var report = new ScanReport { IsClean = true };

            try
            {
                if (!Directory.Exists(_pakDirectory))
                {
                    report.IsClean = false;
                    report.Message = "PAK directory not found.";
                    return report;
                }

                var filesInDirectory = Directory.GetFiles(_pakDirectory)
                    .Select(f => Path.GetFileName(f))
                    .ToList();

                var unauthorizedFiles = filesInDirectory
                    .Where(f => !VerifiedPakFiles.Contains(f))
                    .ToList();

                if (unauthorizedFiles.Count > 0)
                {
                    report.IsClean = false;
                    report.UnauthorizedFiles = unauthorizedFiles;
                    report.Message = $"Found {unauthorizedFiles.Count} unauthorized file(s).";
                    return report;
                }

                var missingFiles = VerifiedPakFiles
                    .Where(vf => !filesInDirectory.Contains(vf, StringComparer.OrdinalIgnoreCase))
                    .ToList();

                if (missingFiles.Count > 0)
                {
                    report.IsClean = false;
                    report.MissingFiles = missingFiles;
                    report.Message = $"Missing {missingFiles.Count} expected PAK file(s).";
                    return report;
                }

                report.Message = "All PAK files verified.";
                return report;
            }
            catch (Exception ex)
            {
                report.IsClean = false;
                report.Message = $"Error scanning PAK directory: {ex.Message}";
                return report;
            }
        }
    }
}